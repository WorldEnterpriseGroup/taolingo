import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-event-left-side-bar',
  templateUrl: './event-left-side-bar.component.html',
  styleUrls: ['./event-left-side-bar.component.css']
})
export class EventLeftSideBarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
