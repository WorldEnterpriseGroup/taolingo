import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-event-right-side-bar',
  templateUrl: './event-right-side-bar.component.html',
  styleUrls: ['./event-right-side-bar.component.css']
})
export class EventRightSideBarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
