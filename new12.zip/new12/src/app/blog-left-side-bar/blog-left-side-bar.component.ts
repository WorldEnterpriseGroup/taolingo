import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blog-left-side-bar',
  templateUrl: './blog-left-side-bar.component.html',
  styleUrls: ['./blog-left-side-bar.component.css']
})
export class BlogLeftSideBarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
