import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blog-right-side-bar',
  templateUrl: './blog-right-side-bar.component.html',
  styleUrls: ['./blog-right-side-bar.component.css']
})
export class BlogRightSideBarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
