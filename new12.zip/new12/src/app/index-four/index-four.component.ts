import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-index-four',
  templateUrl: './index-four.component.html',
  styleUrls: ['./index-four.component.css']
})
export class IndexFourComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
