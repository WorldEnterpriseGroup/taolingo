import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AboutComponent } from './about/about.component';
import { AdvancedComponent } from './advanced/advanced.component';
import { BeginnerComponent } from './beginner/beginner.component';
import { BlogDetailsComponent } from './blog-details/blog-details.component';
import { BlogLeftSideBarComponent } from './blog-left-side-bar/blog-left-side-bar.component';
import { BlogRightSideBarComponent } from './blog-right-side-bar/blog-right-side-bar.component';
import { ContactComponent } from './contact/contact.component';
import { CoursesComponent } from './courses/courses.component';
import { EventComponent } from './event/event.component';
import { EventDetailsComponent } from './event-details/event-details.component';
import { EventLeftSideBarComponent } from './event-left-side-bar/event-left-side-bar.component';
import { EventRightSideBarComponent } from './event-right-side-bar/event-right-side-bar.component';
import { FormComponent } from './form/form.component';
import { Form1Component } from './form1/form1.component';
import { FormtryComponent } from './formtry/formtry.component';
import { IndexComponent } from './index/index.component';
import { IntermediateComponent } from './intermediate/intermediate.component';
import { JournalComponent } from './journal/journal.component';
import { LoginComponent } from './login/login.component';
import { MailComponent } from './mail/mail.component';
import { MethodComponent } from './method/method.component';
import { RequestmodalComponent } from './requestmodal/requestmodal.component';
import { SignupComponent } from './signup/signup.component';
import { SignupFormComponent } from './signup-form/signup-form.component';
import { StepComponent } from './step/step.component';
import { TeacherDetailsComponent } from './teacher-details/teacher-details.component';
import { TeachersComponent } from './teachers/teachers.component';
import { IndexFourComponent } from './index-four/index-four.component';
import { IndexFiveComponent } from './index-five/index-five.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';

@NgModule({
  declarations: [
    AppComponent,
    AboutComponent,
    AdvancedComponent,
    BeginnerComponent,
    BlogDetailsComponent,
    BlogLeftSideBarComponent,
    BlogRightSideBarComponent,
    ContactComponent,
    CoursesComponent,
    EventComponent,
    EventDetailsComponent,
    EventLeftSideBarComponent,
    EventRightSideBarComponent,
    FormComponent,
    Form1Component,
    FormtryComponent,
    IndexComponent,
    IntermediateComponent,
    JournalComponent,
    LoginComponent,
    MailComponent,
    MethodComponent,
    RequestmodalComponent,
    SignupComponent,
    SignupFormComponent,
    StepComponent,
    TeacherDetailsComponent,
    TeachersComponent,
    IndexFourComponent,
    IndexFiveComponent,
    HeaderComponent,
    FooterComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
