import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-index-five',
  templateUrl: './index-five.component.html',
  styleUrls: ['./index-five.component.css']
})
export class IndexFiveComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
