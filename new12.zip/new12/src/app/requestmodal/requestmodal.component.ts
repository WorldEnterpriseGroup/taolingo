import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-requestmodal',
  templateUrl: './requestmodal.component.html',
  styleUrls: ['./requestmodal.component.css']
})
export class RequestmodalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
